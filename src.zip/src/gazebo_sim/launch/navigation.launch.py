from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([

        Node(
            package='astar_planner',
            executable='astar_planner',
            output='screen'
        ),

        Node(
            package='robot_controller',
            executable='path_follower',
            output='screen'
        ),

    ])