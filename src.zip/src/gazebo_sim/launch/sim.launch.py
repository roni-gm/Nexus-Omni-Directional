import os

from launch import LaunchDescription
from launch.actions import ExecuteProcess, SetEnvironmentVariable, TimerAction
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import xacro


def generate_launch_description():

    robot_pkg_path  = get_package_share_directory('robot_description')
    gazebo_pkg_path = get_package_share_directory('gazebo_sim')

    xacro_file  = os.path.join(robot_pkg_path,  'urdf',   'robot.urdf.xacro')
    world_file  = os.path.join(gazebo_pkg_path, 'worlds', 'nexus.world')

    doc        = xacro.process_file(xacro_file)
    robot_desc = doc.toxml()

    gazebo_model_path = os.path.join(robot_pkg_path, '..')
    gazebo_model_env  = os.environ.get('GAZEBO_MODEL_PATH', '')

    # ── 1. Environment vars ────────────────────────────────────────────────
    set_gazebo_model_path = SetEnvironmentVariable(
        name='GAZEBO_MODEL_PATH',
        value=gazebo_model_env + ':' + gazebo_model_path
    )

    # ── 2. Robot State Publisher ───────────────────────────────────────────
    rsp = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_desc,
            'use_sim_time': True,
        }]
    )

    # ── 3. Gazebo + nexus.world ────────────────────────────────────────────
    # nexus.world: ODE iters=150, sor=1.3 → solver 3× lebih akurat per step
    # tanpa world_file → Gazebo pakai default iters=50 → impulse vertikal
    gazebo = ExecuteProcess(
        cmd=[
            'gazebo', '--verbose',
            '-s', 'libgazebo_ros_init.so',
            '-s', 'libgazebo_ros_factory.so',
            world_file,
        ],
        output='screen',
        additional_env={
            'GAZEBO_MODEL_PATH': gazebo_model_env + ':' + gazebo_model_path,
        }
    )

    # ── 4. Velocity Smoother ───────────────────────────────────────────────
    #
    # TOPIC CHAIN (verifikasi dengan ros2 topic list setelah launch):
    #   teleop → /cmd_vel → [smoother] → /cmd_vel_safe → plugin
    #
    # Kalkulasi kenapa smoother wajib:
    #   Tanpa smoother: F_impulse = 7.2 * 1.0 / 0.001 = 7200 N dalam 1 step
    #   Dengan smoother (acc=0.5): delta_v = 0.5*0.001 = 0.0005 m/s per step
    #                              F_eff = 7.2*0.0005/0.001 = 3.6 N
    #   Rasio reduksi: 7200/3.6 = 2000×
    #
    # Remapping KRITIS:
    #   Input smoother  : cmd_vel       → /cmd_vel      (dari teleop)
    #   Output smoother : cmd_vel_smoothed → /cmd_vel_safe (ke plugin)
    #
    # Install: sudo apt install ros-humble-nav2-velocity-smoother
    #
    velocity_smoother = Node(
        package='nav2_velocity_smoother',
        executable='velocity_smoother',
        name='velocity_smoother',
        output='screen',
        parameters=[{
            'use_sim_time':        True,
            'smoothing_frequency': 20.0,       # Hz — update 20× per detik
            'scale_velocities':    False,
            'feedback':            'OPEN_LOOP', # tidak butuh odom untuk smooth
            # [vx, vy, vtheta] — sesuai omni holonomic (3 DOF)
            'max_velocity':        [0.5, 0.5, 1.0],
            'min_velocity':        [-0.5, -0.5, -1.0],
            'max_accel':           [0.5, 0.5, 1.0],   # m/s² — kunci anti-impulse
            'max_decel':           [-0.5, -0.5, -1.0],
            'odom_topic':          'odom',
            'odom_duration':        0.1,
            'deadband_velocity':   [0.001, 0.001, 0.001],  # threshold nol
            'velocity_timeout':     1.0,  # detik tanpa cmd_vel → set ke 0
        }],
        remappings=[
            # PENTING: tanpa remap ini, cmd_vel smoother subscribe ke
            # /velocity_smoother/cmd_vel (namespaced) bukan /cmd_vel global
            ('cmd_vel',          '/cmd_vel'),       # input dari teleop
            ('cmd_vel_smoothed', '/cmd_vel_safe'),  # output ke plugin Gazebo
        ]
    )

    # ── 5. Spawn robot ─────────────────────────────────────────────────────
    #
    # z = 0.069 m dihitung:
    #   wheel_center_z dari base_link = motor_z(0) + wheel_joint_z(-0.033) = -0.033 m
    #   wheel_bottom = -0.033 + (-0.033) = -0.066 m dari base_link
    #   z_spawn = 0.066 + 0.003 (margin) = 0.069 m
    #
    # Margin 3mm (bukan 5mm):
    #   Margin terlalu besar → robot jatuh → bounce → impulse
    #   Margin terlalu kecil → overlap ground → impulse
    #   3mm = satu minDepth (0.001) × 3 → di dalam dead-zone Gazebo
    #   → tidak ada initial contact force
    #
    # TimerAction 3.0s: pastikan Gazebo physics engine sudah fully init
    # sebelum spawn. Jika spawn terlalu cepat → model ditambahkan sebelum
    # world physics aktif → posisi tidak teraplikasikan dengan benar.
    #
    spawn = TimerAction(
        period=3.0,
        actions=[
            Node(
                package='gazebo_ros',
                executable='spawn_entity.py',
                arguments=[
                    '-entity', 'nexus_omni_robot',
                    '-topic',  'robot_description',
                    '-x', '0.0',
                    '-y', '0.0',
                    '-z', '0.069',
                    '-R', '0.0',
                    '-P', '0.0',
                    '-Y', '0.0',
                ],
                output='screen'
            )
        ]
    )

    return LaunchDescription([
        set_gazebo_model_path,
        rsp,
        gazebo,
        velocity_smoother,
        spawn,
    ])