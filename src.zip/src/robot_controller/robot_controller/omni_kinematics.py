import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64MultiArray
import numpy as np

class OmniKinematics(Node):
    def __init__(self):
        super().__init__('omni_kinematics')

        self.subscription = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_callback,
            10
        )

        self.publisher = self.create_publisher(
            Float64MultiArray,
            '/wheel_velocities',
            10
        )

        # PARAMETER ROBOT (HARUS kamu sesuaikan)
        self.L = 0.2   # jarak dari pusat ke roda
        self.alpha = np.pi / 4  # sudut roda omni (biasanya 45°)

    def cmd_callback(self, msg):
        vx = msg.linear.x
        vy = msg.linear.y
        omega = msg.angular.z

        a = self.alpha
        L = self.L

        # inverse kinematics
        v1 = -np.sin(a)*vx + np.cos(a)*vy + L*omega
        v2 = -np.sin(a + np.pi/2)*vx + np.cos(a + np.pi/2)*vy + L*omega
        v3 = -np.sin(a - np.pi)*vx + np.cos(a - np.pi)*vy + L*omega
        v4 = -np.sin(a - np.pi/2)*vx + np.cos(a - np.pi/2)*vy + L*omega

        wheel_msg = Float64MultiArray()
        wheel_msg.data = [v1, v2, v3, v4]

        self.publisher.publish(wheel_msg)


def main(args=None):
    rclpy.init(args=args)
    node = OmniKinematics()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()