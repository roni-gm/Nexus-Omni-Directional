import rclpy
from rclpy.node import Node

from nav_msgs.msg import Path, Odometry
from geometry_msgs.msg import Twist
import math

class PathFollower(Node):
    def __init__(self):
        super().__init__('path_follower')

        self.path = []
        self.current_pose = None

        self.prev_angular = 0.0  # untuk smoothing

        self.create_subscription(Path, '/path', self.path_callback, 10)
        self.create_subscription(Odometry, '/odom', self.odom_callback, 10)

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.timer = self.create_timer(0.1, self.control_loop)

        self.get_logger().info("Path Follower (STABLE VERSION) Started")

    # =========================
    # CALLBACK
    # =========================
    def path_callback(self, msg):
        self.path = msg.poses
        self.get_logger().info(f"Path received: {len(self.path)} points")

    def odom_callback(self, msg):
        self.current_pose = msg.pose.pose

    # =========================
    # UTILITY
    # =========================
    def normalize_angle(self, angle):
        return math.atan2(math.sin(angle), math.cos(angle))

    def get_yaw(self, orientation):
        x = orientation.x
        y = orientation.y
        z = orientation.z
        w = orientation.w

        siny_cosp = 2 * (w*z + x*y)
        cosy_cosp = 1 - 2 * (y*y + z*z)
        return math.atan2(siny_cosp, cosy_cosp)

    # =========================
    # MAIN CONTROL
    # =========================
    def control_loop(self):
        if not self.path or self.current_pose is None:
            return

        target = self.path[0].pose.position

        dx = target.x - self.current_pose.position.x
        dy = target.y - self.current_pose.position.y

        distance = math.hypot(dx, dy)

        cmd = Twist()

        if distance > 0.1:
            # 🔥 target heading
            target_angle = math.atan2(dy, dx)

            # 🔥 current heading
            current_yaw = self.get_yaw(self.current_pose.orientation)

            # 🔥 ERROR (FIX UTAMA)
            error = self.normalize_angle(target_angle - current_yaw)

            # =====================
            # CONTROL GAIN (TUNING)
            # =====================
            K_ANG = 1.5
            K_LIN = 0.3

            # 🔥 angular control
            angular_cmd = K_ANG * error

            # 🔥 CLAMP (hindari osilasi besar)
            angular_cmd = max(min(angular_cmd, 1.0), -1.0)

            # 🔥 SMOOTHING (low-pass filter)
            alpha = 0.7
            angular_cmd = alpha * self.prev_angular + (1 - alpha) * angular_cmd
            self.prev_angular = angular_cmd

            # 🔥 DEADZONE (biar tidak getar kecil)
            if abs(error) < 0.05:
                angular_cmd = 0.0

            cmd.angular.z = angular_cmd

            # 🔥 linear control (hindari zig-zag)
            if abs(error) > 0.3:
                cmd.linear.x = 0.0
            else:
                cmd.linear.x = K_LIN

        else:
            # waypoint tercapai
            self.path.pop(0)

        self.cmd_pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = PathFollower()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()