# astar_planner.py
import heapq
import math

class AStarPlanner:
    def __init__(self):
        # 8-directional movement — omni robot bisa gerak diagonal
        self.DIRECTIONS = [
            (1,0,1.0), (-1,0,1.0), (0,1,1.0), (0,-1,1.0),
            (1,1,1.414), (1,-1,1.414), (-1,1,1.414), (-1,-1,1.414)
        ]

    def plan(self, grid, start, goal):
        """
        grid: 2D numpy array, True=obstacle
        start, goal: (col, row) tuple dalam grid coordinate
        """
        open_set = []
        heapq.heappush(open_set, (0, start))

        came_from = {}
        g_score = {start: 0.0}
        f_score = {start: self._heuristic(start, goal)}

        while open_set:
            _, current = heapq.heappop(open_set)

            if current == goal:
                return self._reconstruct_path(came_from, current)

            cx, cy = current
            for dx, dy, cost in self.DIRECTIONS:
                nx, ny = cx + dx, cy + dy

                # Bounds check
                if not (0 <= ny < grid.shape[0] and 0 <= nx < grid.shape[1]):
                    continue
                # Obstacle check (sudah include inflation)
                if grid[ny, nx]:
                    continue

                neighbor = (nx, ny)
                tentative_g = g_score[current] + cost

                if tentative_g < g_score.get(neighbor, float('inf')):
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + self._heuristic(neighbor, goal)
                    heapq.heappush(open_set, (f_score[neighbor], neighbor))

        return None  # Path tidak ditemukan

    def _heuristic(self, a, b):
        # Octile distance — optimal untuk 8-directional movement
        dx = abs(a[0] - b[0])
        dy = abs(a[1] - b[1])
        return max(dx, dy) + (math.sqrt(2) - 1) * min(dx, dy)

    def _reconstruct_path(self, came_from, current):
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.append(current)
        return list(reversed(path))